// Donat un vector d'enters V, calcula i escriu
// la suma de V[e..d] per a diversos parells e, d.
// Ineficient si es fan moltes preguntes.


#include <iostream>
#include <vector>
using namespace std;


using VI = vector<int>;


int main() {
  int n;
  cin >> n;
  VI V(n);
  for (int& x : V) cin >> x;

  int e, d;
  while (cin >> e >> d) {
    int suma = 0;
    for (int i = e; i <= d; ++i) suma += V[i];
    cout << suma << endl;
  }
}
