// Calcula els nombres de Fibonacci ineficientment.


#include <iostream>
using namespace std;


using ll = long long;


ll fib(int n) {
  if (n <= 1) return n;
  return fib(n - 2) + fib(n - 1);
}


int main() {
  int n;
  while (cin >> n) cout << fib(n) << endl;
}
