// Nombres combinatoris. Versio ineficient.


#include <iostream>
using namespace std;


using ll = long long;


ll combi(int n, int x) {
  if (x == 0 or x == n) return 1;
  return combi(n - 1, x - 1) + combi(n - 1, x);
}


int main() {
  int n, x;
  while (cin >> n >> x) cout << combi(n, x) << endl;
}
